# 01 — Instrucciones de implementación para Google AI Studio

**Objetivo:** completar la aplicación existente NAUTI Space Simulator de Filómatas LAB desde la pantalla de consecuencias de la Jornada 1 hasta el final de la Jornada 5.

## Orden de autoridad de los archivos

1. `03_REGLAS_DEL_JUEGO.json`: valores, estados, finales y efectos diferidos.
2. `02_GUION_NARRATIVO.json`: textos canónicos de cada pantalla, opción y resultado.
3. `04_FLUJO_PANTALLAS.md`: navegación obligatoria.
4. `05_PRUEBAS.ts`: validación de 48 rutas y de sus clasificaciones.

## Preservar

- Jornada 1 completa y sus tres consecuencias existentes.
- Valores iniciales de 50 para Energía, Agua, Salud e Investigación.
- Diseño kawaii espacial, NAUTI nebuloso, paleta Space Navy #101D35, Aqua #48C5B5, Lunar White #EAF4F2 y Star Gold #F2C66D.
- Orientación celular horizontal, audio, bilingüismo, pistas científicas, trivia y MODELAR.
- Los puntos gastables de Ciencia de MODELAR NO son automáticamente el indicador Investigación.

## Implementar

- Sustituir todas las escenas posteriores a la consecuencia de Jornada 1 por las jornadas 2–5 especificadas.
- Mostrar introducción, recapitulación condicional, situación, pista NASA, dos opciones, confirmación, resultado narrativo con explicación de los cuatro indicadores y transición.
- Jornada 5: aplicar primero efectos diferidos, narrar cada causa anterior, luego ofrecer decisión final, evaluar, mostrar informe gráfico, historial y reflexión.
- No crear texto de relleno ni inventar situaciones; usar el JSON íntegro.
- Traducir fielmente el contenido español al inglés dentro del mecanismo de i18n existente.
- Implementar estado persistente con IDs de decisiones y transacciones únicas; reinicio restablece todo a 50.
- Guardar recursos al inicio, después de cada jornada y antes/después de efectos diferidos para la gráfica.
- Si Energía, Agua o Salud llegan a cero o menos, detener de inmediato y mostrar fallo crítico.
- La condición de éxito sostenible exige tres recursos esenciales >=25 e Investigación >=60.
- Los +4 de energía de Jornada 2 por conservar se aplican solo en Jornada 2; no repetir en Jornada 5.
- Si se programaron sesiones cortas en Jornada 2, la investigación final de Jornada 5 cuesta Energía -5, NO -8.
- El 98% de recuperación de agua corresponde a tecnología demostrada en la ISS, no a Base Aurora.
- Las puntuaciones son simplificaciones didácticas, no datos medidos por NASA.

## Validar y entregar

- Ejecutar `05_PRUEBAS.ts` (por ejemplo con `npx tsx 05_PRUEBAS.ts` si el proyecto tiene tsx instalado).
- Se esperan 48 trayectorias: 2 sostenibles, 14 con ciencia lograda y reservas insuficientes, 32 con investigación pendiente, 0 fallos críticos; verificar la distribución con el código.
- Si el código real incluye otros modificadores (trivia/MODELAR/topes de recursos), reportar la diferencia y no cambiar los valores silenciosamente.
- Comprobar todas las pantallas, botones, traducciones, narración y reinicio.
- Reportar archivos modificados, componentes creados, pruebas ejecutadas y problemas pendientes.

**No crear una aplicación nueva: editar la existente.**
