// NAUTI 2.1 — prueba autocontenida de las 48 trayectorias.
// Ejecutar: npx tsx 05_PRUEBAS.ts (o compilar con tsc y ejecutar con node).
type R = {energy:number;water:number;health:number;research:number};
type Outcome = 'CRITICAL_FAILURE'|'SUSTAINABLE_MISSION'|'FRAGILE_SCIENTIFIC_MISSION'|'SCIENTIFIC_GOAL_PENDING';
const start:R={energy:50,water:50,health:50,research:50};
const d1:Record<string,Partial<R>>={LIFE_SUPPORT:{energy:-7,health:8},LABORATORY:{energy:-17,health:-4,research:3},BALANCED:{energy:-10,research:1}};
const d2:Record<string,Partial<R>>={SCHEDULE_SCIENCE:{energy:-5,research:2},CONSERVE_ENERGY:{energy:4,health:1}};
const d3:Record<string,Partial<R>>={MAINTAIN_WATER:{energy:-5,health:1,research:1},POSTPONE_WATER:{energy:-3,research:3}};
const d4:Record<string,Partial<R>>={MAINTAIN_SOLAR:{energy:-5,research:1},CONTINUE_OBSERVATIONS:{energy:-4,research:3}};
const d5:Record<string,Partial<R>>={FINAL_CONSERVATION:{energy:3,health:2},FINAL_RESEARCH:{energy:-8,health:-1,research:4}};
const keys:(keyof R)[]=['energy','water','health','research'];
function apply(r:R, delta:Partial<R>):R {const n={...r};for(const k of keys)n[k]+=(delta[k]??0);return n;}
function critical(r:R):boolean{return r.energy<=0||r.water<=0||r.health<=0;}
function outcome(r:R):Outcome {
 if(critical(r))return 'CRITICAL_FAILURE';
 if(r.research>=60){return r.energy>=25&&r.water>=25&&r.health>=25?'SUSTAINABLE_MISSION':'FRAGILE_SCIENTIFIC_MISSION';}
 return 'SCIENTIFIC_GOAL_PENDING';
}
const counts:Record<Outcome,number>={CRITICAL_FAILURE:0,SUSTAINABLE_MISSION:0,FRAGILE_SCIENTIFIC_MISSION:0,SCIENTIFIC_GOAL_PENDING:0};
const minima={...start},maxima={...start};
let paths=0;
for(const a of Object.keys(d1))for(const b of Object.keys(d2))for(const c of Object.keys(d3))for(const d of Object.keys(d4))for(const e of Object.keys(d5)){
 let r={...start};
 for(const delta of [d1[a],d2[b],d3[c],d4[d]]) {r=apply(r,delta);if(critical(r))throw Error('Fallo crítico antes de Jornada 5');}
 if(c==='POSTPONE_WATER')r=apply(r,{water:-5,health:-1});
 if(d==='CONTINUE_OBSERVATIONS')r=apply(r,{energy:-6});
 if(critical(r))throw Error('Fallo crítico tras efectos diferidos');
 const last={...d5[e]};
 if(b==='SCHEDULE_SCIENCE'&&e==='FINAL_RESEARCH')last.energy=-5;
 r=apply(r,last);
 counts[outcome(r)]++;paths++;
 for(const k of keys){minima[k]=Math.min(minima[k],r[k]);maxima[k]=Math.max(maxima[k],r[k]);}
}
console.log(JSON.stringify({paths,counts,minima,maxima},null,2));
function assert(cond:boolean,msg:string){if(!cond)throw Error(msg);}
assert(paths===48,'Deben existir 48 trayectorias');
assert(counts.CRITICAL_FAILURE===0,'Se esperaban 0 fallos críticos');
assert(counts.SUSTAINABLE_MISSION===2,'Se esperaban 2 misiones sostenibles');
assert(counts.FRAGILE_SCIENTIFIC_MISSION===14,'Se esperaban 14 misiones científicas frágiles');
assert(counts.SCIENTIFIC_GOAL_PENDING===32,'Se esperaban 32 misiones con ciencia pendiente');
assert(minima.energy===8&&maxima.energy===42,'Rango energía inesperado');
assert(minima.water===45&&maxima.water===50,'Rango agua inesperado');
assert(minima.health===44&&maxima.health===62,'Rango salud inesperado');
assert(minima.research===52&&maxima.research===65,'Rango investigación inesperado');
console.log('OK: 48 trayectorias verificadas.');
