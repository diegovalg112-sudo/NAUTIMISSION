# Flujo completo de pantallas — NAUTI 2.1

**Mantener intacta la Jornada 1** y su pantalla de consecuencias. Desde su botón Continuar, reemplazar toda la historia anterior.

## Jornadas 2, 3 y 4

1. Introducción de NAUTI.
2. Recapitulación contextual de la decisión previa.
3. Situación problemática.
4. Ayuda científica NASA (accesible desde la situación/decisión; no revela respuesta).
5. Dos opciones de decisión.
6. Confirmación (Volver / Confirmar).
7. Consecuencia detallada: historia, cuatro indicadores, explicaciones, NAUTI, audio.
8. Transición a la siguiente jornada.

## Jornada 5

1. Introducción.
2. Línea de tiempo de decisiones previas.
3. Tarjetas de efectos diferidos relevantes (aplicar cada transacción una sola vez).
4. Estado de recursos tras los efectos diferidos.
5. Situación de iluminación reducida.
6. Ayuda científica NASA.
7. Dos opciones.
8. Confirmación.
9. Consecuencia narrativa.
10. Evaluación final.
11. Resultado con NAUTI.
12. Gráfico de evolución de recursos (inicio, jornadas 1–5, y subfase de efectos diferidos).
13. Historial de decisiones y causalidad.
14. Tres preguntas de reflexión.
15. Pantalla de partida completada: Repetir misión / Menú principal / Revisar decisiones.

## Finales

Orden de prioridad: (1) recurso esencial <=0: fallo crítico; (2) los tres recursos esenciales >=25 e investigación >=60: sostenible; (3) investigación >=60 y algún esencial <25 pero >0: ciencia con reservas insuficientes; (4) resto con recursos esenciales >0: meta científica pendiente.

La Jornada 5 nunca se debe ejecutar si ocurrió fallo crítico antes. El informe debe describir únicamente decisiones reales.

## Interacción

- Los efectos se aplican **solo al confirmar**.
- Confirmación idempotente: doble clic, retroceso, recarga y reabrir pantalla no duplican efectos.
- Audio: leer, pausar/detener y repetir; nunca modificar recursos al narrar.
- ES/EN: conservar texto español como fuente y traducir fielmente.
- Pantalla móvil horizontal, estética kawaii, personaje NAUTI existente.
- Mantener trivia y MODELAR; sus puntos de Ciencia son distintos del indicador Investigación.
